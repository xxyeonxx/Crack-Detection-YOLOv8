# Crack_Detection > 2025-01-20 2:22pm
https://universe.roboflow.com/jy-gwkor/crack_detection-mjqkw

Provided by a Roboflow user
License: CC BY 4.0

